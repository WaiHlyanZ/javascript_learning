export const NUM_TEN = 10

export function add(x, y) {
    return x + y;
}