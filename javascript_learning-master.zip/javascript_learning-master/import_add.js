import { NUM_TEN, add } from "./export_add_org";

console.log(add(NUM_TEN, 5));